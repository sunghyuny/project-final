import 'package:flutter/material.dart';
import '/services/api_service.dart';

class MyPage extends StatefulWidget {
  @override
  _MyPageState createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  String selectedText = '';
  Map<String, String> userInfo = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchUserInfo();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          '마이페이지',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            letterSpacing: -0.5,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Container(
              color: Colors.grey[100],
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 40,
                        backgroundImage: AssetImage(''), // 사용자 프로필 이미지
                        backgroundColor: Colors.grey,
                      ),
                      SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            userInfo['name'] ?? '',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            userInfo['email'] ?? '',
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                      Spacer(),
                      ElevatedButton(
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                backgroundColor: Colors.white,
                                title: Text(
                                  '개인정보',
                                  style: TextStyle(color: Colors.black),
                                ),
                                content: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('이름: ${userInfo['name']}'),
                                    Text('이메일: ${userInfo['email']}'),
                                    Text('전화번호: ${userInfo['phone']}'),
                                    Text('생년월일: ${userInfo['birthdate']}'),
                                    Text('성별: ${userInfo['gender']}'),
                                    Text('MBTI: ${userInfo['mbti']}'),
                                  ],
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: Text('닫기'),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          foregroundColor: Colors.white,
                          backgroundColor: Colors.blue,
                        ),
                        child: Text('개인정보 보기'),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  Divider(),
                  // 선택된 항목에 따라 다른 콘텐츠 표시
                  if (selectedText == '개인정보')
                    Expanded(
                      child: ListView(
                        children: [
                          ListTile(
                            title: Text('이름'),
                            subtitle: Text(userInfo['name'] ?? ''),
                          ),
                          ListTile(
                            title: Text('이메일'),
                            subtitle: Text(userInfo['email'] ?? ''),
                          ),
                          ListTile(
                            title: Text('전화번호'),
                            subtitle: Text(userInfo['phone'] ?? ''),
                          ),
                          ListTile(
                            title: Text('생년월일'),
                            subtitle: Text(userInfo['birthdate'] ?? ''),
                          ),
                          ListTile(
                            title: Text('성별'),
                            subtitle: Text(userInfo['gender'] ?? ''),
                          ),
                          ListTile(
                            title: Text('MBTI'),
                            subtitle: Text(userInfo['mbti'] ?? ''),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
    );
  }
}
